
#include "EverCrypt_StaticConfig.h"
#include "ctypes_cstubs_internals.h"
value _1_EverCrypt_StaticConfig_hacl(value _)
{
   _Bool* x1 = &EverCrypt_StaticConfig_hacl;
   return CTYPES_FROM_PTR(x1);
}
value _2_EverCrypt_StaticConfig_vale(value _)
{
   _Bool* x2 = &EverCrypt_StaticConfig_vale;
   return CTYPES_FROM_PTR(x2);
}
value _3_EverCrypt_StaticConfig_openssl(value _)
{
   _Bool* x3 = &EverCrypt_StaticConfig_openssl;
   return CTYPES_FROM_PTR(x3);
}
value _4_EverCrypt_StaticConfig_bcrypt(value _)
{
   _Bool* x4 = &EverCrypt_StaticConfig_bcrypt;
   return CTYPES_FROM_PTR(x4);
}
