open Ctypes
module Bindings(F:Cstubs.FOREIGN) = struct open F end