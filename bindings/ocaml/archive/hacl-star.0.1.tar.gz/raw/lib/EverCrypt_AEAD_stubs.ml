module CI = Cstubs_internals

external _1_EverCrypt_AEAD_alg_of_state : _ CI.fatptr -> Unsigned.uint8
  = "_1_EverCrypt_AEAD_alg_of_state" 

external _2_EverCrypt_AEAD_create_in
  : Unsigned.uint8 -> _ CI.fatptr -> bytes CI.ocaml -> Unsigned.uint8
  = "_2_EverCrypt_AEAD_create_in" 

external _3_EverCrypt_AEAD_encrypt
  : _ CI.fatptr -> bytes CI.ocaml -> Unsigned.uint32 -> bytes CI.ocaml ->
    Unsigned.uint32 -> bytes CI.ocaml -> Unsigned.uint32 -> bytes CI.ocaml ->
    bytes CI.ocaml -> Unsigned.uint8
  = "_3_EverCrypt_AEAD_encrypt_byte9" "_3_EverCrypt_AEAD_encrypt" 

external _4_EverCrypt_AEAD_decrypt
  : _ CI.fatptr -> bytes CI.ocaml -> Unsigned.uint32 -> bytes CI.ocaml ->
    Unsigned.uint32 -> bytes CI.ocaml -> Unsigned.uint32 -> bytes CI.ocaml ->
    bytes CI.ocaml -> Unsigned.uint8
  = "_4_EverCrypt_AEAD_decrypt_byte9" "_4_EverCrypt_AEAD_decrypt" 

external _5_EverCrypt_AEAD_free : _ CI.fatptr -> unit
  = "_5_EverCrypt_AEAD_free" 

type 'a result = 'a
type 'a return = 'a
type 'a fn =
 | Returns  : 'a CI.typ   -> 'a return fn
 | Function : 'a CI.typ * 'b fn  -> ('a -> 'b) fn
let map_result f x = f x
let returning t = Returns t
let (@->) f p = Function (f, p)
let foreign : type a b. string -> (a -> b) fn -> (a -> b) =
  fun name t -> match t, name with
| Function (CI.Pointer _, Returns CI.Void), "EverCrypt_AEAD_free" ->
  (fun x1 -> let CI.CPointer x2 = x1 in _5_EverCrypt_AEAD_free x2)
| Function
    (CI.Pointer _,
     Function
       (CI.OCaml CI.Bytes,
        Function
          (CI.Primitive CI.Uint32_t,
           Function
             (CI.OCaml CI.Bytes,
              Function
                (CI.Primitive CI.Uint32_t,
                 Function
                   (CI.OCaml CI.Bytes,
                    Function
                      (CI.Primitive CI.Uint32_t,
                       Function
                         (CI.OCaml CI.Bytes,
                          Function
                            (CI.OCaml CI.Bytes,
                             Returns
                               (CI.View
                                  {CI.ty = CI.Primitive CI.Uint8_t;
                                   read = x13; _})))))))))),
  "EverCrypt_AEAD_decrypt" ->
  (fun x3 x5 x6 x7 x8 x9 x10 x11 x12 ->
    let CI.CPointer x4 = x3 in
    x13 (_4_EverCrypt_AEAD_decrypt x4 x5 x6 x7 x8 x9 x10 x11 x12))
| Function
    (CI.Pointer _,
     Function
       (CI.OCaml CI.Bytes,
        Function
          (CI.Primitive CI.Uint32_t,
           Function
             (CI.OCaml CI.Bytes,
              Function
                (CI.Primitive CI.Uint32_t,
                 Function
                   (CI.OCaml CI.Bytes,
                    Function
                      (CI.Primitive CI.Uint32_t,
                       Function
                         (CI.OCaml CI.Bytes,
                          Function
                            (CI.OCaml CI.Bytes,
                             Returns
                               (CI.View
                                  {CI.ty = CI.Primitive CI.Uint8_t;
                                   read = x24; _})))))))))),
  "EverCrypt_AEAD_encrypt" ->
  (fun x14 x16 x17 x18 x19 x20 x21 x22 x23 ->
    let CI.CPointer x15 = x14 in
    x24 (_3_EverCrypt_AEAD_encrypt x15 x16 x17 x18 x19 x20 x21 x22 x23))
| Function
    (CI.View {CI.ty = CI.Primitive CI.Uint8_t; write = x26; _},
     Function
       (CI.Pointer _,
        Function
          (CI.OCaml CI.Bytes,
           Returns (CI.View {CI.ty = CI.Primitive CI.Uint8_t; read = x31; _})))),
  "EverCrypt_AEAD_create_in" ->
  (fun x25 x28 x30 ->
    let CI.CPointer x29 = x28 in
    let x27 = x26 x25 in x31 (_2_EverCrypt_AEAD_create_in x27 x29 x30))
| Function
    (CI.Pointer _,
     Returns (CI.View {CI.ty = CI.Primitive CI.Uint8_t; read = x34; _})),
  "EverCrypt_AEAD_alg_of_state" ->
  (fun x32 ->
    let CI.CPointer x33 = x32 in x34 (_1_EverCrypt_AEAD_alg_of_state x33))
| _, s ->  Printf.ksprintf failwith "No match for %s" s


let foreign_value : type a. string -> a Ctypes.typ -> a Ctypes.ptr =
  fun name t -> match t, name with
| _, s ->  Printf.ksprintf failwith "No match for %s" s
