module CI = Cstubs_internals

external _1_EverCrypt_Hash_alg_of_state : _ CI.fatptr -> Unsigned.uint8
  = "_1_EverCrypt_Hash_alg_of_state" 

external _2_EverCrypt_Hash_create_in : Unsigned.uint8 -> CI.voidp
  = "_2_EverCrypt_Hash_create_in" 

external _3_EverCrypt_Hash_create : Unsigned.uint8 -> CI.voidp
  = "_3_EverCrypt_Hash_create" 

external _4_EverCrypt_Hash_init : _ CI.fatptr -> unit
  = "_4_EverCrypt_Hash_init" 

external _5_EverCrypt_Hash_update_multi_256
  : _ CI.fatptr -> Bytes.t CI.ocaml -> Unsigned.uint32 -> unit
  = "_5_EverCrypt_Hash_update_multi_256" 

external _6_EverCrypt_Hash_update : _ CI.fatptr -> Bytes.t CI.ocaml -> unit
  = "_6_EverCrypt_Hash_update" 

external _7_EverCrypt_Hash_update_multi
  : _ CI.fatptr -> Bytes.t CI.ocaml -> Unsigned.uint32 -> unit
  = "_7_EverCrypt_Hash_update_multi" 

external _8_EverCrypt_Hash_update_last_256
  : _ CI.fatptr -> Unsigned.uint64 -> Bytes.t CI.ocaml -> Unsigned.uint32 ->
    unit = "_8_EverCrypt_Hash_update_last_256" 

external _9_EverCrypt_Hash_update_last
  : _ CI.fatptr -> Bytes.t CI.ocaml -> Unsigned.uint64 -> unit
  = "_9_EverCrypt_Hash_update_last" 

external _10_EverCrypt_Hash_finish : _ CI.fatptr -> Bytes.t CI.ocaml -> unit
  = "_10_EverCrypt_Hash_finish" 

external _11_EverCrypt_Hash_free : _ CI.fatptr -> unit
  = "_11_EverCrypt_Hash_free" 

external _12_EverCrypt_Hash_copy : _ CI.fatptr -> _ CI.fatptr -> unit
  = "_12_EverCrypt_Hash_copy" 

external _13_EverCrypt_Hash_hash_256
  : Bytes.t CI.ocaml -> Unsigned.uint32 -> Bytes.t CI.ocaml -> unit
  = "_13_EverCrypt_Hash_hash_256" 

external _14_EverCrypt_Hash_hash_224
  : Bytes.t CI.ocaml -> Unsigned.uint32 -> Bytes.t CI.ocaml -> unit
  = "_14_EverCrypt_Hash_hash_224" 

external _15_EverCrypt_Hash_hash
  : Unsigned.uint8 -> Bytes.t CI.ocaml -> Bytes.t CI.ocaml ->
    Unsigned.uint32 -> unit = "_15_EverCrypt_Hash_hash" 

external _16_EverCrypt_Hash_Incremental_alg_of_state
  : _ CI.fatptr -> Unsigned.uint8
  = "_16_EverCrypt_Hash_Incremental_alg_of_state" 

external _17_EverCrypt_Hash_Incremental_create_in
  : Unsigned.uint8 -> CI.voidp = "_17_EverCrypt_Hash_Incremental_create_in" 

external _18_EverCrypt_Hash_Incremental_init : _ CI.fatptr -> unit
  = "_18_EverCrypt_Hash_Incremental_init" 

external _19_EverCrypt_Hash_Incremental_update
  : _ CI.fatptr -> Bytes.t CI.ocaml -> Unsigned.uint32 -> unit
  = "_19_EverCrypt_Hash_Incremental_update" 

external _20_EverCrypt_Hash_Incremental_finish
  : _ CI.fatptr -> Bytes.t CI.ocaml -> unit
  = "_20_EverCrypt_Hash_Incremental_finish" 

external _21_EverCrypt_Hash_Incremental_free : _ CI.fatptr -> unit
  = "_21_EverCrypt_Hash_Incremental_free" 

type 'a result = 'a
type 'a return = 'a
type 'a fn =
 | Returns  : 'a CI.typ   -> 'a return fn
 | Function : 'a CI.typ * 'b fn  -> ('a -> 'b) fn
let map_result f x = f x
let returning t = Returns t
let (@->) f p = Function (f, p)
let foreign : type a b. string -> (a -> b) fn -> (a -> b) =
  fun name t -> match t, name with
| Function (CI.Pointer _, Returns CI.Void), "EverCrypt_Hash_Incremental_free" ->
  (fun x1 -> _21_EverCrypt_Hash_Incremental_free (CI.cptr x1))
| Function (CI.Pointer _, Function (CI.OCaml CI.Bytes, Returns CI.Void)),
  "EverCrypt_Hash_Incremental_finish" ->
  (fun x2 x3 -> _20_EverCrypt_Hash_Incremental_finish (CI.cptr x2) x3)
| Function
    (CI.Pointer _,
     Function
       (CI.OCaml CI.Bytes,
        Function (CI.Primitive CI.Uint32_t, Returns CI.Void))),
  "EverCrypt_Hash_Incremental_update" ->
  (fun x4 x5 x6 -> _19_EverCrypt_Hash_Incremental_update (CI.cptr x4) x5 x6)
| Function (CI.Pointer _, Returns CI.Void), "EverCrypt_Hash_Incremental_init" ->
  (fun x7 -> _18_EverCrypt_Hash_Incremental_init (CI.cptr x7))
| Function
    (CI.View {CI.ty = CI.Primitive CI.Uint8_t; write = x9; _},
     Returns (CI.Pointer x11)),
  "EverCrypt_Hash_Incremental_create_in" ->
  (fun x8 ->
    let x10 = x9 x8 in
    CI.make_ptr x11 (_17_EverCrypt_Hash_Incremental_create_in x10))
| Function
    (CI.Pointer _,
     Returns (CI.View {CI.ty = CI.Primitive CI.Uint8_t; read = x13; _})),
  "EverCrypt_Hash_Incremental_alg_of_state" ->
  (fun x12 ->
    x13 (_16_EverCrypt_Hash_Incremental_alg_of_state (CI.cptr x12)))
| Function
    (CI.View {CI.ty = CI.Primitive CI.Uint8_t; write = x15; _},
     Function
       (CI.OCaml CI.Bytes,
        Function
          (CI.OCaml CI.Bytes,
           Function (CI.Primitive CI.Uint32_t, Returns CI.Void)))),
  "EverCrypt_Hash_hash" ->
  (fun x14 x17 x18 x19 ->
    let x16 = x15 x14 in _15_EverCrypt_Hash_hash x16 x17 x18 x19)
| Function
    (CI.OCaml CI.Bytes,
     Function
       (CI.Primitive CI.Uint32_t,
        Function (CI.OCaml CI.Bytes, Returns CI.Void))),
  "EverCrypt_Hash_hash_224" -> _14_EverCrypt_Hash_hash_224
| Function
    (CI.OCaml CI.Bytes,
     Function
       (CI.Primitive CI.Uint32_t,
        Function (CI.OCaml CI.Bytes, Returns CI.Void))),
  "EverCrypt_Hash_hash_256" -> _13_EverCrypt_Hash_hash_256
| Function (CI.Pointer _, Function (CI.Pointer _, Returns CI.Void)),
  "EverCrypt_Hash_copy" ->
  (fun x26 x27 -> _12_EverCrypt_Hash_copy (CI.cptr x26) (CI.cptr x27))
| Function (CI.Pointer _, Returns CI.Void), "EverCrypt_Hash_free" ->
  (fun x28 -> _11_EverCrypt_Hash_free (CI.cptr x28))
| Function (CI.Pointer _, Function (CI.OCaml CI.Bytes, Returns CI.Void)),
  "EverCrypt_Hash_finish" ->
  (fun x29 x30 -> _10_EverCrypt_Hash_finish (CI.cptr x29) x30)
| Function
    (CI.Pointer _,
     Function
       (CI.OCaml CI.Bytes,
        Function (CI.Primitive CI.Uint64_t, Returns CI.Void))),
  "EverCrypt_Hash_update_last" ->
  (fun x31 x32 x33 -> _9_EverCrypt_Hash_update_last (CI.cptr x31) x32 x33)
| Function
    (CI.Pointer _,
     Function
       (CI.Primitive CI.Uint64_t,
        Function
          (CI.OCaml CI.Bytes,
           Function (CI.Primitive CI.Uint32_t, Returns CI.Void)))),
  "EverCrypt_Hash_update_last_256" ->
  (fun x34 x35 x36 x37 ->
    _8_EverCrypt_Hash_update_last_256 (CI.cptr x34) x35 x36 x37)
| Function
    (CI.Pointer _,
     Function
       (CI.OCaml CI.Bytes,
        Function (CI.Primitive CI.Uint32_t, Returns CI.Void))),
  "EverCrypt_Hash_update_multi" ->
  (fun x38 x39 x40 -> _7_EverCrypt_Hash_update_multi (CI.cptr x38) x39 x40)
| Function (CI.Pointer _, Function (CI.OCaml CI.Bytes, Returns CI.Void)),
  "EverCrypt_Hash_update" ->
  (fun x41 x42 -> _6_EverCrypt_Hash_update (CI.cptr x41) x42)
| Function
    (CI.Pointer _,
     Function
       (CI.OCaml CI.Bytes,
        Function (CI.Primitive CI.Uint32_t, Returns CI.Void))),
  "EverCrypt_Hash_update_multi_256" ->
  (fun x43 x44 x45 ->
    _5_EverCrypt_Hash_update_multi_256 (CI.cptr x43) x44 x45)
| Function (CI.Pointer _, Returns CI.Void), "EverCrypt_Hash_init" ->
  (fun x46 -> _4_EverCrypt_Hash_init (CI.cptr x46))
| Function
    (CI.View {CI.ty = CI.Primitive CI.Uint8_t; write = x48; _},
     Returns (CI.Pointer x50)),
  "EverCrypt_Hash_create" ->
  (fun x47 ->
    let x49 = x48 x47 in CI.make_ptr x50 (_3_EverCrypt_Hash_create x49))
| Function
    (CI.View {CI.ty = CI.Primitive CI.Uint8_t; write = x52; _},
     Returns (CI.Pointer x54)),
  "EverCrypt_Hash_create_in" ->
  (fun x51 ->
    let x53 = x52 x51 in CI.make_ptr x54 (_2_EverCrypt_Hash_create_in x53))
| Function
    (CI.Pointer _,
     Returns (CI.View {CI.ty = CI.Primitive CI.Uint8_t; read = x56; _})),
  "EverCrypt_Hash_alg_of_state" ->
  (fun x55 -> x56 (_1_EverCrypt_Hash_alg_of_state (CI.cptr x55)))
| _, s ->  Printf.ksprintf failwith "No match for %s" s


let foreign_value : type a. string -> a Ctypes.typ -> a Ctypes.ptr =
  fun name t -> match t, name with
| _, s ->  Printf.ksprintf failwith "No match for %s" s
