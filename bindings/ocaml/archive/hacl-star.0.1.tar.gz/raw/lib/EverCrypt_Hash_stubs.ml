module CI = Cstubs_internals

external _1_EverCrypt_Hash_alg_of_state : _ CI.fatptr -> Unsigned.uint8
  = "_1_EverCrypt_Hash_alg_of_state" 

external _2_EverCrypt_Hash_create_in : Unsigned.uint8 -> CI.voidp
  = "_2_EverCrypt_Hash_create_in" 

external _3_EverCrypt_Hash_create : Unsigned.uint8 -> CI.voidp
  = "_3_EverCrypt_Hash_create" 

external _4_EverCrypt_Hash_init : _ CI.fatptr -> unit
  = "_4_EverCrypt_Hash_init" 

external _5_EverCrypt_Hash_update_multi_256
  : _ CI.fatptr -> bytes CI.ocaml -> Unsigned.uint32 -> unit
  = "_5_EverCrypt_Hash_update_multi_256" 

external _6_EverCrypt_Hash_update : _ CI.fatptr -> bytes CI.ocaml -> unit
  = "_6_EverCrypt_Hash_update" 

external _7_EverCrypt_Hash_update_multi
  : _ CI.fatptr -> bytes CI.ocaml -> Unsigned.uint32 -> unit
  = "_7_EverCrypt_Hash_update_multi" 

external _8_EverCrypt_Hash_update_last_256
  : _ CI.fatptr -> Unsigned.uint64 -> bytes CI.ocaml -> Unsigned.uint32 ->
    unit = "_8_EverCrypt_Hash_update_last_256" 

external _9_EverCrypt_Hash_update_last
  : _ CI.fatptr -> bytes CI.ocaml -> Unsigned.uint64 -> unit
  = "_9_EverCrypt_Hash_update_last" 

external _10_EverCrypt_Hash_finish : _ CI.fatptr -> bytes CI.ocaml -> unit
  = "_10_EverCrypt_Hash_finish" 

external _11_EverCrypt_Hash_free : _ CI.fatptr -> unit
  = "_11_EverCrypt_Hash_free" 

external _12_EverCrypt_Hash_copy : _ CI.fatptr -> _ CI.fatptr -> unit
  = "_12_EverCrypt_Hash_copy" 

external _13_EverCrypt_Hash_hash_256
  : bytes CI.ocaml -> Unsigned.uint32 -> bytes CI.ocaml -> unit
  = "_13_EverCrypt_Hash_hash_256" 

external _14_EverCrypt_Hash_hash_224
  : bytes CI.ocaml -> Unsigned.uint32 -> bytes CI.ocaml -> unit
  = "_14_EverCrypt_Hash_hash_224" 

external _15_EverCrypt_Hash_hash
  : Unsigned.uint8 -> bytes CI.ocaml -> bytes CI.ocaml -> Unsigned.uint32 ->
    unit = "_15_EverCrypt_Hash_hash" 

external _16_EverCrypt_Hash_Incremental_alg_of_state
  : _ CI.fatptr -> Unsigned.uint8
  = "_16_EverCrypt_Hash_Incremental_alg_of_state" 

external _17_EverCrypt_Hash_Incremental_create_in
  : Unsigned.uint8 -> CI.voidp = "_17_EverCrypt_Hash_Incremental_create_in" 

external _18_EverCrypt_Hash_Incremental_init : _ CI.fatptr -> unit
  = "_18_EverCrypt_Hash_Incremental_init" 

external _19_EverCrypt_Hash_Incremental_update
  : _ CI.fatptr -> bytes CI.ocaml -> Unsigned.uint32 -> unit
  = "_19_EverCrypt_Hash_Incremental_update" 

external _20_EverCrypt_Hash_Incremental_finish
  : _ CI.fatptr -> bytes CI.ocaml -> unit
  = "_20_EverCrypt_Hash_Incremental_finish" 

external _21_EverCrypt_Hash_Incremental_free : _ CI.fatptr -> unit
  = "_21_EverCrypt_Hash_Incremental_free" 

type 'a result = 'a
type 'a return = 'a
type 'a fn =
 | Returns  : 'a CI.typ   -> 'a return fn
 | Function : 'a CI.typ * 'b fn  -> ('a -> 'b) fn
let map_result f x = f x
let returning t = Returns t
let (@->) f p = Function (f, p)
let foreign : type a b. string -> (a -> b) fn -> (a -> b) =
  fun name t -> match t, name with
| Function (CI.Pointer _, Returns CI.Void), "EverCrypt_Hash_Incremental_free" ->
  (fun x1 ->
    let CI.CPointer x2 = x1 in _21_EverCrypt_Hash_Incremental_free x2)
| Function (CI.Pointer _, Function (CI.OCaml CI.Bytes, Returns CI.Void)),
  "EverCrypt_Hash_Incremental_finish" ->
  (fun x3 x5 ->
    let CI.CPointer x4 = x3 in _20_EverCrypt_Hash_Incremental_finish x4 x5)
| Function
    (CI.Pointer _,
     Function
       (CI.OCaml CI.Bytes,
        Function (CI.Primitive CI.Uint32_t, Returns CI.Void))),
  "EverCrypt_Hash_Incremental_update" ->
  (fun x6 x8 x9 ->
    let CI.CPointer x7 = x6 in _19_EverCrypt_Hash_Incremental_update x7 x8 x9)
| Function (CI.Pointer _, Returns CI.Void), "EverCrypt_Hash_Incremental_init" ->
  (fun x10 ->
    let CI.CPointer x11 = x10 in _18_EverCrypt_Hash_Incremental_init x11)
| Function
    (CI.View {CI.ty = CI.Primitive CI.Uint8_t; write = x13; _},
     Returns (CI.Pointer x15)),
  "EverCrypt_Hash_Incremental_create_in" ->
  (fun x12 ->
    let x14 = x13 x12 in
    CI.make_ptr x15 (_17_EverCrypt_Hash_Incremental_create_in x14))
| Function
    (CI.Pointer _,
     Returns (CI.View {CI.ty = CI.Primitive CI.Uint8_t; read = x18; _})),
  "EverCrypt_Hash_Incremental_alg_of_state" ->
  (fun x16 ->
    let CI.CPointer x17 = x16 in
    x18 (_16_EverCrypt_Hash_Incremental_alg_of_state x17))
| Function
    (CI.View {CI.ty = CI.Primitive CI.Uint8_t; write = x20; _},
     Function
       (CI.OCaml CI.Bytes,
        Function
          (CI.OCaml CI.Bytes,
           Function (CI.Primitive CI.Uint32_t, Returns CI.Void)))),
  "EverCrypt_Hash_hash" ->
  (fun x19 x22 x23 x24 ->
    let x21 = x20 x19 in _15_EverCrypt_Hash_hash x21 x22 x23 x24)
| Function
    (CI.OCaml CI.Bytes,
     Function
       (CI.Primitive CI.Uint32_t,
        Function (CI.OCaml CI.Bytes, Returns CI.Void))),
  "EverCrypt_Hash_hash_224" -> _14_EverCrypt_Hash_hash_224
| Function
    (CI.OCaml CI.Bytes,
     Function
       (CI.Primitive CI.Uint32_t,
        Function (CI.OCaml CI.Bytes, Returns CI.Void))),
  "EverCrypt_Hash_hash_256" -> _13_EverCrypt_Hash_hash_256
| Function (CI.Pointer _, Function (CI.Pointer _, Returns CI.Void)),
  "EverCrypt_Hash_copy" ->
  (fun x31 x33 ->
    let CI.CPointer x34 = x33 in
    let CI.CPointer x32 = x31 in _12_EverCrypt_Hash_copy x32 x34)
| Function (CI.Pointer _, Returns CI.Void), "EverCrypt_Hash_free" ->
  (fun x35 -> let CI.CPointer x36 = x35 in _11_EverCrypt_Hash_free x36)
| Function (CI.Pointer _, Function (CI.OCaml CI.Bytes, Returns CI.Void)),
  "EverCrypt_Hash_finish" ->
  (fun x37 x39 ->
    let CI.CPointer x38 = x37 in _10_EverCrypt_Hash_finish x38 x39)
| Function
    (CI.Pointer _,
     Function
       (CI.OCaml CI.Bytes,
        Function (CI.Primitive CI.Uint64_t, Returns CI.Void))),
  "EverCrypt_Hash_update_last" ->
  (fun x40 x42 x43 ->
    let CI.CPointer x41 = x40 in _9_EverCrypt_Hash_update_last x41 x42 x43)
| Function
    (CI.Pointer _,
     Function
       (CI.Primitive CI.Uint64_t,
        Function
          (CI.OCaml CI.Bytes,
           Function (CI.Primitive CI.Uint32_t, Returns CI.Void)))),
  "EverCrypt_Hash_update_last_256" ->
  (fun x44 x46 x47 x48 ->
    let CI.CPointer x45 = x44 in
    _8_EverCrypt_Hash_update_last_256 x45 x46 x47 x48)
| Function
    (CI.Pointer _,
     Function
       (CI.OCaml CI.Bytes,
        Function (CI.Primitive CI.Uint32_t, Returns CI.Void))),
  "EverCrypt_Hash_update_multi" ->
  (fun x49 x51 x52 ->
    let CI.CPointer x50 = x49 in _7_EverCrypt_Hash_update_multi x50 x51 x52)
| Function (CI.Pointer _, Function (CI.OCaml CI.Bytes, Returns CI.Void)),
  "EverCrypt_Hash_update" ->
  (fun x53 x55 ->
    let CI.CPointer x54 = x53 in _6_EverCrypt_Hash_update x54 x55)
| Function
    (CI.Pointer _,
     Function
       (CI.OCaml CI.Bytes,
        Function (CI.Primitive CI.Uint32_t, Returns CI.Void))),
  "EverCrypt_Hash_update_multi_256" ->
  (fun x56 x58 x59 ->
    let CI.CPointer x57 = x56 in
    _5_EverCrypt_Hash_update_multi_256 x57 x58 x59)
| Function (CI.Pointer _, Returns CI.Void), "EverCrypt_Hash_init" ->
  (fun x60 -> let CI.CPointer x61 = x60 in _4_EverCrypt_Hash_init x61)
| Function
    (CI.View {CI.ty = CI.Primitive CI.Uint8_t; write = x63; _},
     Returns (CI.Pointer x65)),
  "EverCrypt_Hash_create" ->
  (fun x62 ->
    let x64 = x63 x62 in CI.make_ptr x65 (_3_EverCrypt_Hash_create x64))
| Function
    (CI.View {CI.ty = CI.Primitive CI.Uint8_t; write = x67; _},
     Returns (CI.Pointer x69)),
  "EverCrypt_Hash_create_in" ->
  (fun x66 ->
    let x68 = x67 x66 in CI.make_ptr x69 (_2_EverCrypt_Hash_create_in x68))
| Function
    (CI.Pointer _,
     Returns (CI.View {CI.ty = CI.Primitive CI.Uint8_t; read = x72; _})),
  "EverCrypt_Hash_alg_of_state" ->
  (fun x70 ->
    let CI.CPointer x71 = x70 in x72 (_1_EverCrypt_Hash_alg_of_state x71))
| _, s ->  Printf.ksprintf failwith "No match for %s" s


let foreign_value : type a. string -> a Ctypes.typ -> a Ctypes.ptr =
  fun name t -> match t, name with
| _, s ->  Printf.ksprintf failwith "No match for %s" s
