/* Copyright (c) INRIA and Microsoft Corporation. All rights reserved.
   Licensed under the Apache 2.0 License. */

#ifndef __KREMLIN_ENDIAN_H
#define __KREMLIN_ENDIAN_H

#ifdef __GNUC__
#warning "c_endianness.h is deprecated, include lowstar_endianness.h instead"
#endif

#include "lowstar_endianness.h"

#endif
